const Campaign=require('../engine.js');const D=require('../data.js');const assert=require('node:assert/strict');
for(let player=0;player<3;player++){
 const g=new Campaign(player,'standard');
 function command(){const n=g.nations[player];if(!n.focus){const key=(player===2?['m1','d1','d2','m2','e1','e2','e3','m3','m4','e4','d3','d4']:['d1','d2','m1','m2','e1','e2','e3','m3','m4','e4','d3','d4']).find(k=>!n.completed.includes(k)&&(!D.policies.find(p=>p.id===k).pre||n.completed.includes(D.policies.find(p=>p.id===k).pre)));if(key)g.focus(player,key);}
  if(g.day%7===0){if(n.completed.includes('d2'))for(const o of g.nations.filter(o=>o.id!==player&&!o.surrendered&&!g.atWar(player,o.id)&&!g.friendly(player,o.id)).sort((a,b)=>n.relations[b.id]-n.relations[a.id])){if(n.relations[o.id]<50&&n.pp>=60)g.diplomacy(player,o.id,'improve');if(g.diplomacyReason(player,o.id,'alliance').ok)g.diplomacy(player,o.id,'alliance');}g.ai(player);}
 }
 command();while(!g.result){g.daily();command();assert.ok(g.day<=1080);}console.log('Diplomacy-first country',player,'day',g.day,g.result.outcome,'allied VP',g.result.share.toFixed(3));assert.equal(g.result.outcome,'victory');
}
